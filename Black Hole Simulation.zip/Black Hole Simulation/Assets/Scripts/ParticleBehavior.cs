﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleBehavior : MonoBehaviour {


	//public float circularSpeed = 30;
	public float inwardSpeed;
	public float circularSpeed;
	public float angle = 0;
	public float radius = 15f;
	public int objects = 0;
	public static int timesRun = 0;
	public static int tick2 = 0;
	public float myVelocity;
	public static float semimajorAxis;
	public float period;
	public float radiusDividing = 5f;
	public static bool isInCircle = false;
	public static bool objectSelected = false;
	public static bool startTick2 = false;
	public static List<float> velocities = new List<float>();
	public static GameObject randomObject;
	public Transform target;


	public static float average;
	public Color tempColor;

	void Start(){
		BlackHole.particles.Add (this.gameObject);
		randomObject = BlackHole.particles [Random.Range (0, BlackHole.tick)];
	}

	void Update () {
		//Movement of particles
		gameObject.GetComponent<Renderer> ().material.color = Color.clear;
		transform.RotateAround (Vector3.zero, Vector3.up, circularSpeed * Time.deltaTime);
		transform.position = new Vector3 (transform.position.x, -1, transform.position.z);
		float step = inwardSpeed * Time.deltaTime;
		transform.position = Vector3.MoveTowards (transform.position, target.position, step);
		//BlackHole.copies.transform.parent = gameObject.transform;

		//CALCULATING VELOCITY AND PERIOD:
		semimajorAxis = Vector3.Distance (target.position, transform.position);
		period = (Mathf.Sqrt ((semimajorAxis * (0.0170782276f / 214.93946938362f)) * (semimajorAxis * (0.0170782276f / 214.93946938362f)) * (semimajorAxis * (0.0170782276f / 214.93946938362f))) / 20.0f) * 365f;
		myVelocity = (((2 * Mathf.PI) * semimajorAxis) * (0.0170782276f * 695700000)) / (period * 86400);
		//(Mathf.Pow(1.496f, 11.0f)) / (period * 86400);
		//print (myVelocity + "m/s");
		////////////////////////////////////////////////////////////

		if ((semimajorAxis > ((radius / radiusDividing) * 4))) {
			gameObject.GetComponent<Renderer> ().material.color = Color.red;
		} else if (semimajorAxis < ((radius / radiusDividing) * 4) && semimajorAxis >= ((radius / radiusDividing) * 3)) {
			gameObject.GetComponent<Renderer> ().material.color = Color.yellow;

		} else if (semimajorAxis < ((radius / radiusDividing) * 3) && semimajorAxis >= ((radius / radiusDividing) * 2.25f)) {
			gameObject.GetComponent<Renderer> ().material.color = Color.white;
		} else if (semimajorAxis < ((radius / radiusDividing) * 2.25f) && semimajorAxis >= ((radius / radiusDividing) * 1)) {
			gameObject.GetComponent<Renderer> ().material.color = Color.blue;
		} else {
			gameObject.GetComponent<Renderer> ().material.color = Color.blue;
		}

		Color myColor = GetComponent<Renderer> ().material.color;

//		print (randomObject);
		//	&& myColor.Equals (Color.red) && randomObject == this.gameObject && randomObject != null
		if (Input.GetKeyDown ("r")) {
			print ("activate red");
			objectSelected = true;
			startTick2 = true;
			velocities.Add(myVelocity);
			print (velocities);
			//gameObject.GetComponent<Renderer> ().material.color = Color.green;
		} else if (Input.GetKeyDown ("y") && myColor.Equals (Color.yellow) && randomObject == this.gameObject && randomObject != null) {
			print ("activate yellow");
		} else if (Input.GetKeyDown ("w") && myColor.Equals (Color.white) && randomObject == this.gameObject && randomObject != null) {
			print ("activate white");
		} else if (Input.GetKeyDown ("b") && myColor.Equals (Color.blue) && randomObject == this.gameObject && randomObject != null) {
			print ("activate blue");
		}
		if (Input.GetKeyDown ("c")) {
			
		}
//		if (startTick2 && objectSelected && tick2 < 100000) {
//			tick2++;
//		} else {
//			tick2 = 0;
//			startTick2 = false;
//			objectSelected = false;
//		}
	}



		/// DETECTION OF CLICKING AND WRITING INFO


}
		
		


