﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BlackHole : MonoBehaviour {
	
	public bool isInCircle = false;
	public static int particleID = 0;

	public static int tick = 0;
	public int spawnRate = 1; //Smaller the spawnRate the faster the particles spawn
	public bool firstTime = true;
	public Transform prefab;
	public static List<GameObject> particles = new List<GameObject> ();
	public static Transform copies;


	void OnTriggerEnter(Collider other) {
		if (other.gameObject.name != "SpawnRadius") {
			Destroy (other.gameObject);
		}
	}
	void Update(){
		particleID++;
		particleID = particleID / 100;

		//COPYING THE PARTICLES:
		tick++;

		//Copying particles
		//if (tick % spawnRate == 0) {
		copies = (Instantiate (prefab, Random.insideUnitSphere * 15, Quaternion.identity));
		//particles.Add (copies);
		firstTime = false;
		//}

	}
}
