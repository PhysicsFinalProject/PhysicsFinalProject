﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

	public float speed = 5.0f;
	bool shouldGo = true;
	void Update()
	{
		float xAxisValue = Input.GetAxis("Horizontal");
		float zAxisValue = Input.GetAxis("Vertical");
		if(Camera.current != null)
		{
			Camera.current.transform.Translate(new Vector3(xAxisValue, 0.0f, zAxisValue));
		}
		if (Input.GetKey ("left")) {
				transform.Rotate(0.5f, 0, 0);
		}
		if (Input.GetKey ("right")) {
				transform.Rotate(-0.5f, 0, 0);
		}
	}
	void OnGUI(){
		float sum = 0;
		if (shouldGo) {
			if (ParticleBehavior.objectSelected) {
				for (int i = 0; i < ParticleBehavior.velocities.Count; i++) {
					sum += ParticleBehavior.velocities [i];
				}
				//print (average + "          JFEKD:JFSKDF:CJSDLF:DS");
				shouldGo = false;
			}
			ParticleBehavior.average = sum / (ParticleBehavior.velocities.Count + 1);

		}
		GUI.Label (new Rect (10, 10, 500, 100), "Velocity is: " + ParticleBehavior.average/1000 + " km/s");

		ParticleBehavior.timesRun++;
	}
}
